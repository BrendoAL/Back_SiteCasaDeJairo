package com.lambda.APICasaDeJairo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCasaDeJairoApplicationTests {

	@Test
	void contextLoads() {
	}

}
