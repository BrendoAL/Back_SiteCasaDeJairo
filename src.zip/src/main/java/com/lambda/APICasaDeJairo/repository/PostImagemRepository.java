package com.lambda.APICasaDeJairo.repository;

import com.lambda.APICasaDeJairo.models.PostImagem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PostImagemRepository extends JpaRepository<PostImagem, Long> {
}
